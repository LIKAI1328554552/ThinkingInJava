CREATE TRIGGER escloud.DS_DEL_LSFW_LASQ_SSQQ ON escloud.LSFW_LASQ_SSQQ FOR DELETE AS
IF (UPPER(suser_name()) <> UPPER('esxxtb'))BEGIN
INSERT INTO escloud.DS_LSFW_LASQ_SSQQ(DS_ACTIONE,DS_DATE,DS_ISAFTER,DS_sFields,DS_tFields,c_id)(SELECT 'D',getDate(),'N','c_id,c_lasqid,c_ssqq','c_id,c_lasqid,c_ssqq',c_id FROM deleted WHERE 1<2 )
END
