CREATE TRIGGER escloud.DS_UPDATE_noticeinfo ON escloud.noticeinfo FOR UPDATE AS
IF (UPPER(suser_name()) <> UPPER(''))
BEGIN 
IF @@rowcount=1 
INSERT INTO escloud.DS_noticeinfo(DS_ACTIONE,DS_DATE,DS_ISAFTER,DS_sFields,DS_tFields,nid,nid_1) (SELECT 'U',getDate(),'Y','nid,title,writerid,writetime,content,puboff,importance,attachment,state,pubstime,endtime,readnum,operator,opttime,fblb,shrid,fhrid,shyj,fhyj,fbrid','nid,title,writerid,writetime,content,puboff,importance,attachment,state,pubstime,endtime,readnum,operator,opttime,fblb,shrid,fhrid,shyj,fhyj,fbrid',inserted.nid,deleted.nid FROM inserted,deleted WHERE 1<2 )
ELSE 
INSERT INTO escloud.DS_noticeinfo(DS_ACTIONE,DS_DATE,DS_ISAFTER,DS_sFields,DS_tFields,nid,nid_1) (SELECT 'U',getDate(),'Y','nid,title,writerid,writetime,content,puboff,importance,attachment,state,pubstime,endtime,readnum,operator,opttime,fblb,shrid,fhrid,shyj,fhyj,fbrid','nid,title,writerid,writetime,content,puboff,importance,attachment,state,pubstime,endtime,readnum,operator,opttime,fblb,shrid,fhrid,shyj,fhyj,fbrid',inserted.nid,inserted.nid FROM inserted WHERE 1<2 )
END
