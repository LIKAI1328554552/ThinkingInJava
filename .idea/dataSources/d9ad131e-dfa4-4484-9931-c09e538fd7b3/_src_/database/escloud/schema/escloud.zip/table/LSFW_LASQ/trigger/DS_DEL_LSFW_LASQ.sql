CREATE TRIGGER escloud.DS_DEL_LSFW_LASQ ON escloud.LSFW_LASQ FOR DELETE AS
IF (UPPER(suser_name()) <> UPPER('esxxtb'))BEGIN
INSERT INTO escloud.DS_LSFW_LASQ(DS_ACTIONE,DS_DATE,DS_ISAFTER,DS_sFields,DS_tFields,c_id,xh)(SELECT 'D',getDate(),'N','c_id,xh,n_fyid,n_sslx,n_lsid,d_sqsj,c_ssyly,c_fgly,n_sfjssqtj,n_zt,d_qssj,c_qsr,c_fghf,d_hfsj,ah,d_fssj,bcsj,jzsj,case_sn,n_yhid,n_ajly','c_id,xh,n_fyid,n_sslx,n_lsid,d_sqsj,c_ssyly,c_fgly,n_sfjssqtj,n_zt,d_qssj,c_qsr,c_fghf,d_hfsj,ah,d_fssj,bcsj,jzsj,case_sn,n_yhid,n_ajly',c_id,xh FROM deleted WHERE 1<2 )
END
