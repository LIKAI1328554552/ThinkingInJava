','court_no,pxh,progbh,lmmc,xssx,wzsr,jptj,qybz,glry,qtlj,htlj,lmtp,bttp,jwtp,wjml,ylzd1,ylzd2,sfsh,shjb,yjry,ejry,other2','court_no,pxh,progbh,lmmc,xssx,wzsr,jptj,qybz,glry,qtlj,htlj,lmtp,bttp,jwtp,wjml,ylzd1,ylzd2,sfsh,shjb,yjry,ejry,other2',court_no,pxCREATE TRIGGER escloud.DS_DEL_web_program_jz ON escloud.web_program_jz FOR DELETE AS
IF (UPPER(suser_name()) <> UPPER(''))BEGIN
INSERT INTO escloud.DS_web_program_jz(DS_ACTIONE,DS_DATE,DS_ISAFTER,DS_sFields,DS_tFields,court_no,pxh)(SELECT 'D',getDate(),'Nh FROM deleted WHERE 1<2 )
END
