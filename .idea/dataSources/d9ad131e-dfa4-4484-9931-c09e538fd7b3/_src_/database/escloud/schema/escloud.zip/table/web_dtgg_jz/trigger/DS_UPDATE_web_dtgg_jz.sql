ime,owner,attname,attachment,tanchu,source,other1,pxh','court_no,nid,title,content,link,btime,etime,owner,attname,attachment,tanchu,source,other1,pxh',inserted.court_no,inserted.nid,inserted.court_no,inserted.nid FROM inserted WHERE 1<2 )
END
,deleted.court_no,deleted.nid FROM inserted,deleted WHERE 1<2 )
ELSE 
INSERT INTO escloud.DS_web_dtgg_jz(DS_ACTIONE,DS_DATE,DS_ISAFTER,DS_sFields,DS_tFields,court_no,nid,court_no_1,nid_1) (SELECT 'U',getDate(),'Y','court_no,nid,title,content,link,btime,etCREATE TRIGGER escloud.DS_UPDATE_web_dtgg_jz ON escloud.web_dtgg_jz FOR UPDATE AS
IF (UPPER(suser_name()) <> UPPER(''))
BEGIN 
IF @@rowcount=1 
INSERT INTO escloud.DS_web_dtgg_jz(DS_ACTIONE,DS_DATE,DS_ISAFTER,DS_sFields,DS_tFields,court_no,nid,court_no_1,nid_1) (SELECT 'U',getDate(),'Y','court_no,nid,title,content,link,btime,etime,owner,attname,attachment,tanchu,source,other1,pxh','court_no,nid,title,content,link,btime,etime,owner,attname,attachment,tanchu,source,other1,pxh',inserted.court_no,inserted.nid