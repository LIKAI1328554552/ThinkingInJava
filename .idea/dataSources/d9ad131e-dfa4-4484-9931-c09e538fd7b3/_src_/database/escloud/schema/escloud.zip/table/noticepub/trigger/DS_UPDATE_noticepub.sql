CREATE TRIGGER escloud.DS_UPDATE_noticepub ON escloud.noticepub FOR UPDATE AS
IF (UPPER(suser_name()) <> UPPER(''))
BEGIN 
IF @@rowcount=1 
INSERT INTO escloud.DS_noticepub(DS_ACTIONE,DS_DATE,DS_ISAFTER,DS_sFields,DS_tFields,pubid,pubid_1) (SELECT 'U',getDate(),'Y','pubid,nid,pubrange,rangetype,readedid','pubid,nid,pubrange,rangetype,readedid',inserted.pubid,deleted.pubid FROM inserted,deleted WHERE 1<2 )
ELSE 
INSERT INTO escloud.DS_noticepub(DS_ACTIONE,DS_DATE,DS_ISAFTER,DS_sFields,DS_tFields,pubid,pubid_1) (SELECT 'U',getDate(),'Y','pubid,nid,pubrange,rangetype,readedid','pubid,nid,pubrange,rangetype,readedid',inserted.pubid,inserted.pubid FROM inserted WHERE 1<2 )
END
