','court_no,axh,pxh,maintitle,subtitle,author,pubtime,content,atype,docnum,docdept,signer,keywords,titlenote,readnum,picurl,attname,attachment,source,disflag,aformat,other1,other2,zt,lrr,lrsj,videourl,picure2','court_no,axh,pxh,maintitle,subtitle,author,pCREATE TRIGGER escloud.DS_DEL_web_article_jz ON escloud.web_article_jz FOR DELETE AS
IF (UPPER(suser_name()) <> UPPER(''))BEGIN
INSERT INTO escloud.DS_web_article_jz(DS_ACTIONE,DS_DATE,DS_ISAFTER,DS_sFields,DS_tFields,court_no,axh)(SELECT 'D',getDate(),'Nubtime,content,atype,docnum,docdept,signer,keywords,titlenote,readnum,picurl,attname,attachment,source,disflag,aformat,other1,other2,zt,lrr,lrsj,videourl,picure2',court_no,axh FROM deleted WHERE 1<2 )
END
