CREATE TRIGGER escloud.DS_UPDATE_OA_ZW ON escloud.OA_ZW FOR UPDATE AS
IF (UPPER(suser_name()) <> UPPER('esxxtb'))
BEGIN 
IF @@rowcount=1 
INSERT INTO escloud.DS_OA_ZW(DS_ACTIONE,DS_DATE,DS_ISAFTER,DS_sFields,DS_tFields,ID,ID_1) (SELECT 'U',getDate(),'Y','ID,ZW,FJID','ID,ZW,FJID',inserted.ID,deleted.ID FROM inserted,deleted WHERE 1<2 )
ELSE 
INSERT INTO escloud.DS_OA_ZW(DS_ACTIONE,DS_DATE,DS_ISAFTER,DS_sFields,DS_tFields,ID,ID_1) (SELECT 'U',getDate(),'Y','ID,ZW,FJID','ID,ZW,FJID',inserted.ID,inserted.ID FROM inserted WHERE 1<2 )
END
