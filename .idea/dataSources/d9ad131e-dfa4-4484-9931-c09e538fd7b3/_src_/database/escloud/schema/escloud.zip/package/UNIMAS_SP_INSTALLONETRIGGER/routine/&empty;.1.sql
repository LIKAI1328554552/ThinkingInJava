

CREATE proc escloud.UNIMAS_SP_INSTALLONETRIGGER
@dbName varchar(255),--数据库名称
@todoTbl varchar(255), --todo表的名称
@tblName varchar(255),--表的名称
@act	varchar(3),	--是否是增删改
@cat	varchar(3),	--是否是增删改的异常处理
@user	varchar(255),	--数据库所有者
@triggername varchar(50),
@params varchar(1847)
as
declare @pkName varchar(255)	--单个关键字的名称
declare @pkType varchar(255)	--pk的类型
declare @pkPrec	int	--pk的长度
declare @pkScale int 	--pk的精度

declare @strSQL nvarchar(4000)	--要执行的SQL语句
declare @strSQL0 nvarchar(4000)	--要执行的SQL语句
declare @strPKs nvarchar(2550)	--主关键字字符串，多个关键字名称之间用逗号分隔
declare @strPKTypes nvarchar(2550) --主关键字类型字符串，多个关键字类型之间用逗号分隔
declare @strSelect nvarchar(3000)  ----更新行的数据选择
declare @strSelDel nvarchar(3000)  ----更新行的数据选择
declare @strUpdatingPK nvarchar(3000) --更新主键
declare @intFor int		--循环变量
declare @strIU varchar(255)
declare @inDid integer
declare @keyCnt integer
declare @ckeyCnt integer
declare @keyName varchar(255)
declare @strPKSQL varchar(2000)
declare @tiggerName varchar(50)
declare @year varchar(4)
declare @month varchar(2)
declare @day varchar(2)
begin
select @tiggerName=@triggername
--select @tiggerName=convert(varchar,object_id('escloud.'+@tblName))+substring(@todoTbl,8,datalength(@todoTbl))
select @keyCnt=keycnt,@inDid=indid from sysindexes where  id=object_id(@tblName) and status2 & 2 = 2 and status & 2048 = 2048
select @ckeyCnt = @keyCnt
while (@keyCnt >0)
begin
select @keyName=index_col(@tblName,@inDid,@keyCnt) from   sysindexes  where status2 & 2 = 2 and status & 2048 = 2048  and keycnt>0
select @pkName=c.name,@pkType=t.name,@pkPrec=c.prec,@pkScale=c.scale from syscolumns c join systypes t on c.type=t.type and c.usertype=t.usertype where id=object_id(@tblName) and c.name = @keyName
IF(@ckeyCnt = @keyCnt)
    begin
        select @strPKs=@pkName
        select @strPKTypes=@pkType

        IF(PATINDEX('%datetime%',@pkType)<>0 or PATINDEX('%DATETIME%',@pkType)<>0)
            begin
                select @strSelect='select (right(''0000''+convert(varchar,datepart(year,inserted.'+@pkName+')),4)+''-''+right(''00''+convert(varchar,datepart(month,inserted.'+@pkName+')),2)+''-''+right(''00''+convert(varchar,datepart(day,inserted.'+@pkName+')),2)+'' '''+'+convert(varchar,inserted.'+@pkName+',108)+''.'''+'+substring(convert(varchar(12),'+@pkName+',20),10,12)'
                select @strSelDel='select (right(''0000''+convert(varchar,datepart(year,deleted.'+@pkName+')),4)+''-''+right(''00''+convert(varchar,datepart(month,deleted.'+@pkName+')),2)+''-''+right(''00''+convert(varchar,datepart(day,deleted.'+@pkName+')),2)+'' '''+'+convert(varchar,deleted.'+@pkName+',108)+''.'''+'+substring(convert(varchar(12),'+@pkName+',20),10,12)'
            end
        ELSE IF(PATINDEX('date',@pkType)<>0 or PATINDEX('DATE',@pkType)<>0)
            begin
                select @strSelect='select (right(''0000''+convert(varchar,datepart(year,inserted.'+@pkName+')),4)+''-''+right(''00''+convert(varchar,datepart(month,inserted.'+@pkName+')),2)+''-''+right(''00''+convert(varchar,datepart(day,inserted.'+@pkName+')),2)'
                select @strSelDel='select (right(''0000''+convert(varchar,datepart(year,deleted.'+@pkName+')),4)+''-''+right(''00''+convert(varchar,datepart(month,deleted.'+@pkName+')),2)+''-''+right(''00''+convert(varchar,datepart(day,deleted.'+@pkName+')),2)'
            end
        ELSE IF(PATINDEX('time',@pkType)<>0 or PATINDEX('TIME',@pkType)<>0)
            begin
                select @strSelect='select (convert(varchar,inserted.'+@pkName+',108)+''.'''+'+substring(convert(varchar(12),'+@pkName+',20),10,12)'
                select @strSelDel='select (convert(varchar,deleted.'+@pkName+',108)+''.'''+'+substring(convert(varchar(12),'+@pkName+',20),10,12)'
            end
        ELSE IF(PATINDEX('%float%',@pkType)<>0 or PATINDEX('%FLOAT%',@pkType)<>0)
            begin
                select @strSelect='select (str_replace(str_replace(str_replace(convert(varchar('+cast(@pkPrec as varchar(255))+'),inserted.'+@pkName+ ' ,2),''\'',''\\''),'','',''\,''),'';'',''\;'')'
                select @strSelDel='select (str_replace(str_replace(str_replace(convert(varchar('+cast(@pkPrec as varchar(255))+'),deleted.'+@pkName+ ' ,2),''\'',''\\''),'','',''\,''),'';'',''\;'')'
            end
        ELSE
            begin
                select @strSelect='select (str_replace(str_replace(str_replace(cast(inserted.'+@pkName+ ' as varchar(4000)),''\'',''\\''),'','',''\,''),'';'',''\;'')'
                select @strSelDel='select (str_replace(str_replace(str_replace(cast(deleted.'+@pkName+ ' as varchar(4000)),''\'',''\\''),'','',''\,''),'';'',''\;'')'
            end
        select @strUpdatingPK='update('+@pkName+')'
    end
ELSE
    begin
        select @strPKs=@strPKs+','+@pkName
        select @strPKTypes=@strPKTypes+','+@pkType
        IF(PATINDEX('%datetime%',@pkType)<>0 or PATINDEX('%DATETIME%',@pkType)<>0)
            begin
                select @strSelect=@strSelect+'+'',''+right(''0000''+convert(varchar,datepart(year,inserted.'+@pkName+')),4)+''-''+right(''00''+convert(varchar,datepart(month,inserted.'+@pkName+')),2)+''-''+right(''00''+convert(varchar,datepart(day,inserted.'+@pkName+')),2)+'' '''+'+convert(varchar,inserted.'+@pkName+',108)+''.'''+'+substring(convert(varchar(12),'+@pkName+',20),10,12)'
                select @strSelDel=@strSelDel+'+'',''+right(''0000''+convert(varchar,datepart(year,deleted.'+@pkName+')),4)+''-''+right(''00''+convert(varchar,datepart(month,deleted.'+@pkName+')),2)+''-''+right(''00''+convert(varchar,datepart(day,deleted.'+@pkName+')),2)+'' '''+'+convert(varchar,deleted.'+@pkName+',108)+''.'''+'+substring(convert(varchar(12),'+@pkName+',20),10,12)'
                --select @strSelect=@strSelect+'+'',''+convert(varchar,datepart(year,inserted.'+@pkName+'))+''-''+right(''00''+convert(varchar,datepart(month,inserted.'+@pkName+')),2)+''-''+right(''00''+convert(varchar,datepart(day,inserted.'+@pkName+')),2)+'' '''+'+convert(varchar,inserted.'+@pkName+',20)'
                --select @strSelDel=@strSelDel+'+'',''+convert(varchar,datepart(year,deleted.'+@pkName+'))+''-''+right(''00''+convert(varchar,datepart(month,deleted.'+@pkName+')),2)+''-''+right(''00''+convert(varchar,datepart(day,deleted.'+@pkName+')),2)+'' '''+'+convert(varchar,deleted.'+@pkName+',20)'
            end
	    ELSE IF(PATINDEX('date',@pkType)<>0 or PATINDEX('DATE',@pkType)<>0)
            begin
                select @strSelect=@strSelect+'+'',''+right(''0000''+convert(varchar,datepart(year,inserted.'+@pkName+')),4)+''-''+right(''00''+convert(varchar,datepart(month,inserted.'+@pkName+')),2)+''-''+right(''00''+convert(varchar,datepart(day,inserted.'+@pkName+')),2)'
                select @strSelDel=@strSelDel+'+'',''+right(''0000''+convert(varchar,datepart(year,deleted.'+@pkName+')),4)+''-''+right(''00''+convert(varchar,datepart(month,deleted.'+@pkName+')),2)+''-''+right(''00''+convert(varchar,datepart(day,deleted.'+@pkName+')),2)'
            end
	    ELSE IF(PATINDEX('time',@pkType)<>0 or PATINDEX('TIME',@pkType)<>0)
            begin
                select @strSelect=@strSelect+'+'',''+convert(varchar,inserted.'+@pkName+',108)+''.'''+'+substring(convert(varchar(12),'+@pkName+',20),10,12)'
                select @strSelDel=@strSelDel+'+'',''+convert(varchar,deleted.'+@pkName+',108)+''.'''+'+substring(convert(varchar(12),'+@pkName+',20),10,12)'
            end
        ELSE IF(PATINDEX('%float%',@pkType)<>0 or PATINDEX('%FLOAT%',@pkType)<>0)
            begin
                select @strSelect=@strSelect+'+'',''+str_replace(str_replace(str_replace(convert(varchar('+cast(@pkPrec as varchar(255))+'),inserted.'+@pkName+ ',2 ),''\'',''\\''),'','',''\,''),'';'',''\;'')'
                select @strSelDel=@strSelDel+'+'',''+str_replace(str_replace(str_replace(convert(varchar('+cast(@pkPrec as varchar(255))+'),deleted.'+@pkName+ ',2 ),''\'',''\\''),'','',''\,''),'';'',''\;'')'
            end
        ELSE
            begin
                select @strSelect=@strSelect+'+'',''+str_replace(str_replace(str_replace(cast(inserted.'+@pkName+ ' as varchar(4000)),''\'',''\\''),'','',''\,''),'';'',''\;'')'
                select @strSelDel=@strSelDel+'+'',''+str_replace(str_replace(str_replace(cast(deleted.'+@pkName+ ' as varchar(4000)),''\'',''\\''),'','',''\,''),'';'',''\;'')'
            end
        select @strUpdatingPK=@strUpdatingPK+' or update('+@pkName+')'
    end
    select @keyCnt = @keyCnt - 1
end

select @strSelect=@strSelect+' ) from inserted'
select @strSelDel=@strSelDel+' ) from deleted'
declare @strIfExists nvarchar(800) --删除触发器语句

select @strIfExists='IF EXISTS (SELECT name FROM sysobjects WHERE name = ''UMTS_TODO'+@tiggerName+'I'' AND type = ''TR'') DROP TRIGGER UMTS_TODO'+@tiggerName+'I'
execute sp_exec_SQL @strIfExists,null	--执行删除触发器

select @strIfExists='IF EXISTS (SELECT name FROM sysobjects WHERE name = ''UMTS_TODO'+@tiggerName+'U'' AND type = ''TR'') DROP TRIGGER UMTS_TODO'+@tiggerName+'U'
execute sp_exec_SQL @strIfExists,null	--执行删除触发器

 --执行删除删除触发器
select @strIfExists='IF EXISTS (SELECT name FROM sysobjects WHERE name = ''UMTS_TODO'+@tiggerName+'D'' AND type = ''TR'') DROP TRIGGER UMTS_TODO'+@tiggerName+'D'
execute sp_exec_SQL @strIfExists,null	--执行删除触发器

if(PATINDEX('%i%',@act)<>0 or PATINDEX('%I%',@act)<>0)
    begin
      select @strSQL0='create trigger UMTS_TODO'+@tiggerName+'I on '+@user+'.'+@tblName+' for insert as '
		+' begin
declare @strVals    nvarchar(2550)
declare @strInsert  nvarchar(4000)
declare curUpdated  cursor for '+@strSelect+'
open curUpdated
fetch curUpdated  into @strVals
while @@sqlstatus=0
begin
select @strInsert=''insert into '+@user+'.'+@todoTbl+'(dbname,tblname,pks,mark,act) values('''''+@dbName+''''','''+char(39)+@tblName+char(39)+''','''+char(39)+@strPKs+';'+@strPKTypes+';''+@strVals+'';'''',1,''''i'''')''
execute sp_exec_SQL @strInsert,null
fetch curUpdated  into @strVals
end'
select @strSQL='
close curUpdated
deallocate cursor curUpdated
if @@error<>0 '
			if(PATINDEX('%i%',@cat)<>0 or PATINDEX('%I%',@cat)<>0)
				begin
					select @strSQL=@strSQL+'
				print '' Unknown Exception Raised: trigger "UMTS_TODO'+@tblName+'I"'''
				end
			else
				begin
					select @strSQL=@strSQL+'return'
				end
			select @strSQL=@strSQL+'
			end'
		exec ( @strSQL0+ @strSQL)
		end


if(PATINDEX('%u%',@act)<>0 or PATINDEX('%U%',@act)<>0)

		begin
		select @strSQL0='create trigger UMTS_TODO'+@tiggerName+'U on '+@user+'.'+@tblName+' for update as '
		+' begin
			declare @oldVals    nvarchar(2550)
			declare @newVals    nvarchar(2550)
	 		declare @strInsert  nvarchar(4000)
			declare curUpdated  cursor for '+@strSelect+'
			declare curDeleted  cursor for '+@strSelDel+'

			open curUpdated
			open curDeleted

			fetch curUpdated  into @newVals
			fetch curDeleted  into @oldVals
			while @@sqlstatus=0
			begin
				if '+@strUpdatingPK+'
				  begin
                    select @strInsert=''insert into '+@user+'.'+@todoTbl+'(dbname,tblname,pks,mark,act) values('''''+@dbName+''''','''+char(39)+@tblName+char(39)+''','''+char(39)+@strPKs+';'+@strPKTypes+';''+@oldVals+'';'''',1,''''d'''')''
                    execute sp_exec_SQL @strInsert,null
                    select @strInsert=''insert into '+@user+'.'+@todoTbl+'(dbname,tblname,pks,mark,act) values('''''+@dbName+''''','''+char(39)+@tblName+char(39)+''','''+char(39)+@strPKs+';'+@strPKTypes+';''+@newVals+'';'''',1,''''i'''')''
                    execute sp_exec_SQL @strInsert,null
				  end
				else'
   select @strSQL='
begin
					select @strInsert=''insert into '+@user+'.'+@todoTbl+'(dbname,tblname,pks,mark,act) values('''''+@dbName+''''','''+char(39)+@tblName+char(39)+''','''+char(39)+@strPKs+';'+@strPKTypes+';''+@newVals+'';'''',1,''''u'''')''
				    execute sp_exec_SQL @strInsert,null
				  end
				fetch curUpdated  into @newVals
				fetch curDeleted  into @oldVals
			end
			close curDeleted
			close curUpdated
			deallocate cursor curDeleted
			deallocate cursor curUpdated
			--print @strInsert
			if @@error<>0 '

			if(PATINDEX('%u%',@cat)<>0 or PATINDEX('%U%',@cat)<>0)
				begin
					select @strSQL=@strSQL+'
				print '' Unknown Exception Raised: trigger "UMTS_TODO'+@tblName+'U"'''
				end
			else
				begin
				select @strSQL=@strSQL+'return'
				end
			select @strSQL=@strSQL+'
		  end'


		exec ( @strSQL0+ @strSQL)
end

if(PATINDEX('%d%',@act)<>0 or PATINDEX('%D%',@act)<>0)
		begin
		if(@params is not null and @params <> '')
          begin
              set @strSelDel=@strSelDel+'  where  '+@params
          end
		select @strSQL0='create trigger UMTS_TODO'+@tiggerName+'D on '+@user+'.'+@tblName+' for delete as '
		+'begin
			declare @strVals    nvarchar(2550)
		 	declare @strInsertD  nvarchar(4000)
			declare curUpdated  cursor for 	'+@strSelDel+'
			open curUpdated
			fetch curUpdated into @strVals
			while @@sqlstatus=0
			begin
				select @strInsertD=''insert into '+@user+'.'+@todoTbl+'(dbname,tblname,pks,mark,act) values('''''+@dbName+''''','''+char(39)+@tblName+char(39)+''','''+char(39)+@strPKs+';'+@strPKTypes+';''+@strVals+'';'''',1,''''d'''')''
				execute sp_exec_SQL @strInsertD,null
				fetch curUpdated into @strVals
			end'
select @strSQL='
			close curUpdated
			deallocate cursor curUpdated
			if @@error<>0 '
			if(PATINDEX('%d%',@cat)<>0 or PATINDEX('%D%',@cat)<>0)
				begin
					select @strSQL=@strSQL+'
				print '' Unknown Exception Raised: trigger "UMTS_TODO'+@tblName+'D"'''
				end
			else
				begin
					select @strSQL=@strSQL+'return'
				end
			select @strSQL=@strSQL+'
		  end'
		  --print @strSQL
		exec ( @strSQL0+ @strSQL)
		end
	if @@error<>0
   		select @@error





end

