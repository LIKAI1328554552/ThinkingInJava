CREATE TRIGGER escloud.DS_INSERT_noticepub ON escloud.noticepub FOR INSERT AS
IF (UPPER(suser_name()) <> UPPER(''))BEGIN
INSERT INTO escloud.DS_noticepub(DS_ACTIONE,DS_DATE,DS_ISAFTER,DS_sFields,DS_tFields,pubid)(SELECT 'I',getDate(),'Y','pubid,nid,pubrange,rangetype,readedid','pubid,nid,pubrange,rangetype,readedid',pubid FROM inserted WHERE 1<2 )
END
