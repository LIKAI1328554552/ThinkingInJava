CREATE TRIGGER escloud.DS_DEL_noticepub ON escloud.noticepub FOR DELETE AS
IF (UPPER(suser_name()) <> UPPER(''))BEGIN
INSERT INTO escloud.DS_noticepub(DS_ACTIONE,DS_DATE,DS_ISAFTER,DS_sFields,DS_tFields,pubid)(SELECT 'D',getDate(),'N','pubid,nid,pubrange,rangetype,readedid','pubid,nid,pubrange,rangetype,readedid',pubid FROM deleted WHERE 1<2 )
END
