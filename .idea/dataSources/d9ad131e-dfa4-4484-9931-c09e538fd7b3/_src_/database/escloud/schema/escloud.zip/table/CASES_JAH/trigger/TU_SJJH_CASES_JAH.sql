create trigger TU_SJJH_CASES_JAH	
   on CASES_JAH for update,insert
as
begin
   declare 
      @errno   int,
      @errmsg  varchar(255),
      @exists_time int,
      @now_time datetime,
      @oldsn numeric(15,0)

   select @now_time = max(GETDATE()) from sysobjects
   select @oldsn = CASE_SN from inserted
   if @oldsn = null
      return
   select @exists_time = count(*) from SJJH_DATATIME where CASE_SN = @oldsn
   if @exists_time = 0
      insert into SJJH_DATATIME ( CASE_SN,UPDTIME )
      values( @oldsn,@now_time )
   else
      update SJJH_DATATIME set UPDTIME = @now_time where CASE_SN = @oldsn

   return
   error:
      raiserror @errno @errmsg
      rollback  transaction
end
