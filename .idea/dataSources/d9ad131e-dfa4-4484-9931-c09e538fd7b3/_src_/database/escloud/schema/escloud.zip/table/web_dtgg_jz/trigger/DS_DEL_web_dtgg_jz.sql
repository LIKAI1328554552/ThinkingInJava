CREATE TRIGGER escloud.DS_DEL_web_dtgg_jz ON escloud.web_dtgg_jz FOR DELETE AS
IF (UPPER(suser_name()) <> UPPER(''))BEGIN
INSERT INTO escloud.DS_web_dtgg_jz(DS_ACTIONE,DS_DATE,DS_ISAFTER,DS_sFields,DS_tFields,court_no,nid)(SELECT 'D',getDate(),'N','court_no,nid,title,content,link,btime,etime,owner,attname,attachment,tanchu,source,other1,pxh','court_no,nid,title,content,link,btime,etime,owner,attname,attachment,tanchu,source,other1,pxh',court_no,nid FROM deleted WHERE 1<2 )
END
