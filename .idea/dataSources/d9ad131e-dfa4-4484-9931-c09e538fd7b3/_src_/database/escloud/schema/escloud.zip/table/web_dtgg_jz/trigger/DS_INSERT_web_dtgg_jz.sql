CREATE TRIGGER escloud.DS_INSERT_web_dtgg_jz ON escloud.web_dtgg_jz FOR INSERT AS
IF (UPPER(suser_name()) <> UPPER(''))BEGIN
INSERT INTO escloud.DS_web_dtgg_jz(DS_ACTIONE,DS_DATE,DS_ISAFTER,DS_sFields,DS_tFields,court_no,nid)(SELECT 'I',getDate(),'Y','court_no,nid,title,content,link,btime,etime,owner,attname,attachment,tanchu,source,other1,pxh','court_no,nid,title,content,link,btime,etime,owner,attname,attachment,tanchu,source,other1,pxh',court_no,nid FROM inserted WHERE 1<2 )
END
