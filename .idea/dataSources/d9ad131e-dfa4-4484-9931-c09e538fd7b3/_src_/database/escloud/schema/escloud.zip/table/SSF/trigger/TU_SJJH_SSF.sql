

create trigger TU_SJJH_SSF
   on SSF for update,insert,delete
as
begin
   declare 
      @errno   int,
      @errmsg  varchar(255),
      @exists_time int,
      @now_time datetime,
      @oldsn numeric(15,0),
      @opmode	varchar(3),
      @tmptable	v   insert into SJJH_DATATIME ( CASE_SN,UPDTIME )
           values( @oldsn,@now_time )
        else
            update SJJH_DATATIME set UPDTIME = @now_time where CASE_SN = @oldsn
	 end   
   return
   error:
      raiserror @errno @errmsg
      rollback archar(10),
      @inscount	int,
      @delcount	int

   select @now_time = max(GETDATE()) from sysobjects
   select @oldsn = CASE_SN from inserted
   if (@delcount > 0 and @inscount<=0)
	begin
		select @oldsn = CASE_SN from deleted
		
	select @exists_timd
   else
	begin
		select @oldsn = CASE_SN from inserted
		if @delcount > 0 		
			select @opmode='U'
		else
			select @opmode='I'

		select @exists_time = count(*) from SJJH_DATATIME where CASE_SN = @oldsn
       if @exists_time = 0 AND @oldsn >0
        e = count(*) from SJJH_DATATIME where CASE_SN = @oldsn
   if @exists_time = 0
        insert into SJJH_DATATIME ( CASE_SN,UPDTIME )
        values( @oldsn,@now_time )
   else
        update SJJH_DATATIME set UPDTIME = @now_time where CASE_SN = @oldsn

	en transaction
end
