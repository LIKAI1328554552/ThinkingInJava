
create  procedure escloud.UNIMAS_SP_REMOVESYNCTRIGGER
(
@dbName varchar(255),
@todoTbl varchar(255),
@tblName varchar(255)='',
@act varchar(3)='',
@triggername varchar(50)
)
AS
begin
declare @triName varchar(255)
declare @strSql nvarchar(500)
declare @tiggerName varchar(50)

select @tiggerName=@triggername
--select @tiggerName=convert(varchar,object_id('escloud.'+@tblName))+substring(@todoTbl,8,datalength(@todoTbl))
DECLARE curTriggers CURSOR for select name from sysobjects where type='TR' AND name LIKE 'UMTS_TODO'+@tiggerName+'%'
open curTriggers
fetch curTriggers into @triName
while @@sqlstatus=0
begin
	if(PATINDEX('%i%',@act)<>0 or PATINDEX('%I%',@act)<>0)
	begin
		if(@triName='UMTS_TODO'+@tiggerName+'I')
		begin
			select @strSql='drop trigger '+ @triName +''
			execute sp_exec_SQL @strSql,null
		end
	end

	if(PATINDEX('%u%',@act)<>0 or PATINDEX('%U%',@act)<>0)
	begin
		if(@triName='UMTS_TODO'+@tiggerName+'U')
		begin
			select @strSql='drop trigger '+ @triName
			execute sp_exec_SQL @strSql,null
		end
	end

	if(PATINDEX('%d%',@act)<>0 or PATINDEX('%D%',@act)<>0)
	begin
		if(@triName='UMTS_TODO'+@tiggerName+'D')
		begin
			select @strSql='drop trigger '+ @triName
			execute sp_exec_SQL @strSql,null
		end
	end

	if(isnull(@act,'')='')
	begin
		begin
			select @strSql='drop trigger '+ @triName
			execute sp_exec_SQL @strSql,null
		end
	end

	fetch curTriggers into @triName
end
close curTriggers
deallocate cursor curTriggers
end

