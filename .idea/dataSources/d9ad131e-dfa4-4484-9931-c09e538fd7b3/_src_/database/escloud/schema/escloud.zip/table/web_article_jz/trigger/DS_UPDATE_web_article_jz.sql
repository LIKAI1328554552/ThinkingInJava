CREATE TRIGGER escloud.DS_UPDATE_web_article_jz ON escloud.web_article_jz FOR UPDATE AS
IF (UPPER(suser_name()) <> UPPER(''))
BEGIN 
IF @@rowcount=1 
INSERT INTO escloud.DS_web_article_jz(DS_ACTIONE,DS_DATE,DS_ISAFTER,DS_sFields,DS_tFields,court_no,axh,coatype,docnum,docdept,signer,keywords,titlenote,readnum,picurl,attname,attachment,source,disflag,aformat,other1,other2,zt,lrr,lrsj,videourl,picure2','court_no,axh,pxh,maintitle,subtitle,author,pubtime,content,atype,docnum,docdept,signer,keywords,titlenote,t_no,axh,pxh,maintitle,subtitle,author,pubtime,content,atype,docnum,docdept,signer,keywords,titlenote,readnum,picurl,attname,attachment,source,disflag,aformat,other1,other2,zt,lrr,lrsj,videourl,picure2',inserted.court_no,inserted.axh,deleted.court_no,deleted.axh FROM inserted,deleted WHERE 1<2 )
ELSE 
INSERT INTO escloud.DS_web_article_jz(DS_ACTIONE,DS_DATE,DS_ISAFTER,DS_sFields,DS_tFields,court_no,axh,court_no_1,axh_1) (SELECT 'U',getDate(),'Y','court_no,axh,pxh,maintitle,subtitle,author,pubtime,content,urt_no_1,axh_1) (SELECT 'U',getDate(),'Y','court_no,axh,pxh,maintitle,subtitle,author,pubtime,content,atype,docnum,docdept,signer,keywords,titlenote,readnum,picurl,attname,attachment,source,disflag,aformat,other1,other2,zt,lrr,lrsj,videourl,picure2','courreadnum,picurl,attname,attachment,source,disflag,aformat,other1,other2,zt,lrr,lrsj,videourl,picure2',inserted.court_no,inserted.axh,inserted.court_no,inserted.axh FROM inserted WHERE 1<2 )
END
