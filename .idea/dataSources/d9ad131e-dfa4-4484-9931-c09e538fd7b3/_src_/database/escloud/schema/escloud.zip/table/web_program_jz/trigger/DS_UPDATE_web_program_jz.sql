,sfsh,shjb,yjry,ejry,other2',inserted.court_no,inserted.pxh,deleted.court_no,deleted.pxh FROM inserted,deleted WHERE 1<2 )
ELSE 
INSERT INTO escloud.DS_web_program_jz(DS_ACTIONE,DS_DATE,DS_ISAFTER,DS_sFields,DS_tFields,court_no,pxh,court_no_1,pxh_1) (SELECREATE TRIGGER escloud.DS_UPDATE_web_program_jz ON escloud.web_program_jz FOR UPDATE AS
IF (UPPER(suser_name()) <> UPPER(''))
BEGIN 
IF @@rowcount=1 
INSERT INTO escloud.DS_web_program_jz(DS_ACTIONE,DS_DATE,DS_ISAFTER,DS_sFields,DS_tFields,court_no,pxh,coCT 'U',getDate(),'Y','court_no,pxh,progbh,lmmc,xssx,wzsr,jptj,qybz,glry,qtlj,htlj,lmtp,bttp,jwtp,wjml,ylzd1,ylzd2,sfsh,shjb,yjry,ejry,other2','court_no,pxh,progbh,lmmc,xssx,wzsr,jptj,qybz,glry,qtlj,htlj,lmtp,bttp,jwtp,wjml,ylzd1,ylzd2,sfsh,shjb,yjry,ejry,urt_no_1,pxh_1) (SELECT 'U',getDate(),'Y','court_no,pxh,progbh,lmmc,xssx,wzsr,jptj,qybz,glry,qtlj,htlj,lmtp,bttp,jwtp,wjml,ylzd1,ylzd2,sfsh,shjb,yjry,ejry,other2','court_no,pxh,progbh,lmmc,xssx,wzsr,jptj,qybz,glry,qtlj,htlj,lmtp,bttp,jwtp,wjml,ylzd1,ylzd2other2',inserted.court_no,inserted.pxh,inserted.court_no,inserted.pxh FROM inserted WHERE 1<2 )
END
