
create procedure escloud.unimas_exec_SQL (
  @sqlstr	varchar(4000),
  @callerID	varchar(30)
)as
begin
    declare @retval int
    set nocount on
	exec (@sqlstr)
	select @retval = @@error
	if (@retval != 0)
	begin
		raiserror 19206, @callerID, @sqlstr
	end
	set nocount off
	return @retval
end

SET QUOTED_IDENTIFIER ON
