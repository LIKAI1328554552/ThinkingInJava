CREATE TRIGGER escloud.DS_UPDATE_LSFW_LASQ_QSCL ON escloud.LSFW_LASQ_QSCL FOR UPDATE AS
IF (UPPER(suser_name()) <> UPPER('esxxtb'))
BEGIN 
IF @@rowcount=1 
INSERT INTO escloud.DS_LSFW_LASQ_QSCL(DS_ACTIONE,DS_DATE,DS_ISAFTER,DS_sFields,DS_tFields,c_id,c_id_1) (SELECT 'U',getDate(),'Y','c_id,c_lasqid,c_qscllj,c_sm,c_wjnr,c_zt','c_id,c_lasqid,c_qscllj,c_sm,c_wjnr,c_zt',inserted.c_id,deleted.c_id FROM inserted,deleted WHERE 1<2 )
ELSE 
INSERT INTO escloud.DS_LSFW_LASQ_QSCL(DS_ACTIONE,DS_DATE,DS_ISAFTER,DS_sFields,DS_tFields,c_id,c_id_1) (SELECT 'U',getDate(),'Y','c_id,c_lasqid,c_qscllj,c_sm,c_wjnr,c_zt','c_id,c_lasqid,c_qscllj,c_sm,c_wjnr,c_zt',inserted.c_id,inserted.c_id FROM inserted WHERE 1<2 )
END
