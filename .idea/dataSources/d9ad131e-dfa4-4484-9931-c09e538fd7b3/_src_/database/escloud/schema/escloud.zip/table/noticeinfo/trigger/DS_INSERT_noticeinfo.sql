CREATE TRIGGER escloud.DS_INSERT_noticeinfo ON escloud.noticeinfo FOR INSERT AS
IF (UPPER(suser_name()) <> UPPER(''))BEGIN
INSERT INTO escloud.DS_noticeinfo(DS_ACTIONE,DS_DATE,DS_ISAFTER,DS_sFields,DS_tFields,nid)(SELECT 'I',getDate(),'Y','nid,title,writerid,writetime,content,puboff,importance,attachment,state,pubstime,endtime,readnum,operator,opttime,fblb,shrid,fhrid,shyj,fhyj,fbrid','nid,title,writerid,writetime,content,puboff,importance,attachment,state,pubstime,endtime,readnum,operator,opttime,fblb,shrid,fhrid,shyj,fhyj,fbrid',nid FROM inserted WHERE 1<2 )
END
