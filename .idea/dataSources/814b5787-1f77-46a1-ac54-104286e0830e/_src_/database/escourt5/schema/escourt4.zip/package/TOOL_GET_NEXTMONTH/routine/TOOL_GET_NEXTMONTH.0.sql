create proc escourt4.TOOL_GET_NEXTMONTH (@tjny char(6) output)
as
BEGIN
	declare @tjny1 int	
	select @tjny1 = convert(int,right(@tjny,2))
	if @tjny1 > 11
		begin
			select @tjny = convert(char(4),convert(int,left(@tjny,4)) + 1) + '01'
		end
	else
		begin
			select @tjny1 = convert(int,@tjny)
			select @tjny1 = @tjny1 + 1
			select @tjny = convert(char(6),@tjny1)
		end
end

GO