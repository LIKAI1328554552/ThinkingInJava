create procedure up_seconds(@nowdatetime char(25),@outseconds int output)
as
begin
  SELECT @outseconds = datediff( second, "1970-01-01 08:00:00", @nowdatetime)
end

return
 
GO