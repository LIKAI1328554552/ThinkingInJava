create proc escourt4.TOOL_GET_MONTHQSDAY (@tjny char(6),@kssj datetime output,@jssj datetime output)
as
BEGIN	
	                         
	declare @yf char(2),@nd int
	select @yf = right(@tjny,2)
	select @nd = convert(int,left(@tjny,4))
	select @kssj = convert(datetime,left(@tjny,4)+'-'+right(@tjny,2)+'-01 00:00:00')
	if @yf = '02'
		begin
		if ((@nd%4=0 and @nd%100<>0) or (@nd%400=0))
			begin
				select @jssj = convert(datetime,left(@tjny,4)+'-'+right(@tjny,2)+'-29 23:59:59')
			end
		else
			begin
				select @jssj = convert(datetime,left(@tjny,4)+'-'+right(@tjny,2)+'-28 23:59:59')
			end
		end
	else
		if @yf = '04' or @yf='06' or @yf='09' or @yf='11'
			begin
			select @jssj = convert(datetime,left(@tjny,4)+'-'+right(@tjny,2)+'-30 23:59:59')
			end
		else
			begin
			select @jssj = convert(datetime,left(@tjny,4)+'-'+right(@tjny,2)+'-31 23:59:59')
			end
end

GO