CREATE VIEW sxfywz_lm 
       (xh,qh,lm,bt1,bt2,pic1,pic2,nr,author,fbsj,xssx,lmmc,xssx_a) AS SELECT info_sxfy.xh,    
         info_sxfy.qh,    
         info_sxfy.lm,    
         info_sxfy.bt1,    
         info_sxfy.bt2,    
         info_sxfy.pic1,    
         info_sxfy.pic2,    
         info_sxfy.nr,    
         info_sxfy.author,    
         info_sxfy.fbsj,    
         info_sxfy.xssx,    
         info_sxfylm.lmmc,    
         info_sxfylm.xssx   
    FROM info_sxfy,    
         info_sxfylm   
   WHERE ( info_sxfy.qh = info_sxfylm.qh ) and   
         ( info_sxfy.lm = info_sxfylm.xh )
 
GO