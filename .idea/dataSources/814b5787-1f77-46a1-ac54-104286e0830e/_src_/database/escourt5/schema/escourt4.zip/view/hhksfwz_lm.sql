create VIEW hhksfwz_lm (xh,qh,lm,bt1,bt2,pic1,pic2,nr,author,fbsj,xssx,lmmc,xssx_a) AS SELECT info_hhksf.xh,    
         info_hhksf.qh,    
         info_hhksf.lm,    
         info_hhksf.bt1,    
         info_hhksf.bt2,    
         info_hhksf.pic1,    
         info_hhksf.pic2,    
         info_hhksf.nr,    
         info_hhksf.author,    
         info_hhksf.fbsj,    
         info_hhksf.xssx,    
         info_hhksflm.lmmc,    
         info_hhksflm.xssx   
    FROM info_hhksf,    
         info_hhksflm   
   WHERE ( info_hhksf.qh = info_hhksflm.qh ) and   
         ( info_hhksf.lm = info_hhksflm.xh )
 
GO